@include('layouts.template.header')

@include('layouts.template.body')

@include('layouts.template.menu')

@include('layouts.template.title')

@yield('content')

@include('layouts.template.footer')

