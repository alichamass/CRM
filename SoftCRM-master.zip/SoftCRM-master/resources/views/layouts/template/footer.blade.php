<footer>
    <p>
        All right reserved. Template by: <a href="http://webthemez.com">WebThemez</a> | Code by: <a
                href="https://github.com/KamilGrzechulski/">Kamil Grzechulski</a> | @version
    </p>
</footer>
</div>
</div>
</div>
<script src="{{ asset('/js/jquery-1.10.2.js') }}"></script>
<script src="{{ asset('/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('/js/jquery.metisMenu.js') }}"></script>
<script src="{{ asset('/js/custom-scripts.js') }}"></script>
<script src="{{ asset('js/jsclock-0.8.min.js') }}"></script>

</body>

</html>